

## Plan: Website "Lijst van Andel Steenwijkerland"

Een one-page website in de stijl van fvd.nl, maar volledig voor "Lijst van Andel" met de kandidaten Sammy (#1), Lisa Mars (#2) en Nathan ten Wolde (#3).

### Wat wordt er gebouwd

Een donkere, professioneel ogende website met de volgende secties (van boven naar beneden):

1. **Navbar** -- Logo/naam "Lijst van Andel" links, navigatielinks rechts (Over ons, Standpunten, Kandidaten, Contact)

2. **Hero sectie** -- Grote banner met tekst "Lijst van Andel Steenwijkerland" en subtitel over de gemeenteraadsverkiezingen. Donkere achtergrond, gouden accent-kleur (vergelijkbaar met FVD-stijl maar eigen identiteit)

3. **Kandidaten sectie** -- Drie kaarten naast elkaar:
   - **Sammy** (#1, lijsttrekker) -- foto van user-uploads://image.png, bio-tekst uit het oorspronkelijke bericht, speerpunten (woningen, natuur, slimmer bestuur)
   - **Lisa Mars** (#2) -- placeholder foto (geen foto geüpload), korte vermelding
   - **Nathan ten Wolde** (#3) -- foto van user-uploads://image-2.png, bio-tekst uit dit bericht, speerpunten (boerenpraktijk, agrarisch landschap, bestuur vanuit principes)

4. **Standpunten sectie** -- Gecombineerde speerpunten van alle kandidaten in een overzichtelijk grid met iconen:
   - Voorrang voor eigen inwoners
   - Behoud van natuur (Weerribben-Wieden)
   - Slimmer & digitaal bestuur
   - Boerenpraktijk terug in beleid
   - Behoud agrarisch cultuurlandschap
   - Bestuur vanuit principes en gezond verstand

5. **Contact/CTA sectie** -- Eenvoudig contactformulier of call-to-action

6. **Footer** -- Copyright, naam partij

### Technische aanpak

- **Bestanden**: Alles in `src/pages/Index.tsx` met eventueel component-splits voor secties
- **Afbeeldingen**: Kopieer beide uploads naar `src/assets/sammy.png` en `src/assets/nathan.png`
- **Styling**: Tailwind CSS, donker kleurenschema (dark background ~#1a1a2e), goud/amber accenten (#d4a843), witte tekst
- **Responsive**: Mobile-first, grid layout dat stacked op kleinere schermen
- **Geen FVD-verwijzingen**: Alles is "Lijst van Andel", geen FVD logo's, kleuren of teksten
- **Lucide icons** voor de standpunten-iconen

### Bestanden die worden aangemaakt/gewijzigd

| Bestand | Actie |
|---------|-------|
| `src/assets/sammy.png` | Kopieer upload |
| `src/assets/nathan.png` | Kopieer upload |
| `src/pages/Index.tsx` | Volledig herschrijven met de website |
| `src/index.css` | Eventueel kleine aanpassingen voor custom fonts/kleuren |

